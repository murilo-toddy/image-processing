Arquivo zip gerado em: 05/05/2022 00:01:49 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: Assignment 3 - Filtering in Spatial and Frequency Domain